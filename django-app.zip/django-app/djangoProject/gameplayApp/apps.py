from django.apps import AppConfig


class GameplayappConfig(AppConfig):
    name = 'gameplayApp'
